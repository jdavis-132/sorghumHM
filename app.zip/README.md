# maizeHM
Shiny app for searching a B73 gene in another genome and performing comparisons 
